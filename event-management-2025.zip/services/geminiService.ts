
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const geminiService = {
  async generateEventDescription(title: string) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Write an engaging, 2-sentence marketing description for a college event titled "${title}". Focus on fun and attendance.`,
      });
      return response.text;
    } catch (error) {
      console.error("Gemini description error:", error);
      return "An exciting event you don't want to miss!";
    }
  },

  async suggestEventActivities(title: string) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Suggest 3 unique, high-energy activities for a college event called "${title}". Provide a bulleted list.`,
      });
      return response.text;
    } catch (error) {
      console.error("Gemini suggestions error:", error);
      return "1. Fun competitions\n2. Networking\n3. Photo booths";
    }
  }
};
