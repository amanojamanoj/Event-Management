
import React from 'react';
import { Event } from '../types';
import { Calendar, MapPin, Users, Tag } from 'lucide-react';

interface EventCardProps {
  event: Event;
  onClick: (event: Event) => void;
}

const EventCard: React.FC<EventCardProps> = ({ event, onClick }) => {
  const isFull = event.attendeesCount >= event.maxCapacity;

  return (
    <div 
      className="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer border border-slate-100 group"
      onClick={() => onClick(event)}
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={event.image} 
          alt={event.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-indigo-600 shadow-sm uppercase tracking-wider">
          {event.category}
        </div>
        {event.price === 0 && (
          <div className="absolute bottom-4 left-4 bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg">
            FREE
          </div>
        )}
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold mb-2 group-hover:text-indigo-600 transition-colors">{event.title}</h3>
        <p className="text-slate-500 text-sm mb-4 line-clamp-2">{event.description}</p>
        
        <div className="space-y-2">
          <div className="flex items-center text-slate-600 text-sm">
            <Calendar size={16} className="mr-2 text-indigo-400" />
            <span>{event.date} at {event.time}</span>
          </div>
          <div className="flex items-center text-slate-600 text-sm">
            <MapPin size={16} className="mr-2 text-indigo-400" />
            <span>{event.venue}</span>
          </div>
          <div className="flex items-center text-slate-600 text-sm">
            <Users size={16} className="mr-2 text-indigo-400" />
            <div className="flex-1">
              <div className="flex justify-between mb-1">
                <span>{event.attendeesCount} Attending</span>
                <span>{Math.round((event.attendeesCount / event.maxCapacity) * 100)}%</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-1.5">
                <div 
                  className={`h-1.5 rounded-full ${isFull ? 'bg-red-500' : 'bg-indigo-500'}`}
                  style={{ width: `${Math.min(100, (event.attendeesCount / event.maxCapacity) * 100)}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-6 flex items-center justify-between">
          <span className="text-lg font-bold text-slate-900">
            {event.price > 0 ? `₹${event.price}` : 'Entry Free'}
          </span>
          <button className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${isFull ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md hover:shadow-lg'}`}>
            {isFull ? 'Full' : 'Book Now'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default EventCard;
