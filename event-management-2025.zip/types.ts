
export type UserRole = 'user' | 'admin';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  venue: string;
  attendeesCount: number;
  maxCapacity: number;
  category: string;
  price: number;
  image: string;
  schedule: ScheduleItem[];
}

export interface ScheduleItem {
  time: string;
  activity: string;
}

export interface Registration {
  id: string;
  userId: string;
  eventId: string;
  userName: string;
  userEmail: string;
  eventTitle: string;
  status: 'pending' | 'paid';
  paymentMethod: 'cash' | 'online';
  qrCode: string;
  timestamp: string;
}

export interface AppState {
  currentUser: User | null;
  events: Event[];
  registrations: Registration[];
}
