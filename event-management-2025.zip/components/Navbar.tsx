
import React from 'react';
import { User } from '../types';
import { LogOut, Calendar, LayoutDashboard, User as UserIcon, Sparkles } from 'lucide-react';

interface NavbarProps {
  user: User | null;
  onLogout: () => void;
  onNavigate: (view: 'events' | 'admin' | 'my-bookings') => void;
  currentView: string;
}

const Navbar: React.FC<NavbarProps> = ({ user, onLogout, onNavigate, currentView }) => {
  return (
    <nav className="sticky top-0 z-50 bg-white/70 backdrop-blur-xl border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center space-x-3 cursor-pointer group" onClick={() => onNavigate('events')}>
            <div className="w-12 h-12 bg-gradient-to-tr from-indigo-600 to-violet-600 rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-xl group-hover:scale-105 transition-transform">EM</div>
            <div className="flex flex-col">
              <span className="text-xl font-black tracking-tight text-slate-900 leading-none">Event Management</span>
              <span className="text-xs font-bold text-indigo-600 tracking-widest uppercase mt-1">Portal 2025</span>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-10">
            <button 
              onClick={() => onNavigate('events')}
              className={`text-sm font-bold tracking-tight transition-all relative py-1 ${currentView === 'events' ? 'text-indigo-600' : 'text-slate-500 hover:text-indigo-600'}`}
            >
              Explore Events
              {currentView === 'events' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-indigo-600 rounded-full"></span>}
            </button>
            {user?.role === 'user' && (
              <button 
                onClick={() => onNavigate('my-bookings')}
                // Fix: changed 'currentSubView' to 'currentView' as currentSubView was not defined in this scope
                className={`text-sm font-bold tracking-tight transition-all relative py-1 ${currentView === 'my-bookings' ? 'text-indigo-600' : 'text-slate-500 hover:text-indigo-600'}`}
              >
                My Tickets
              </button>
            )}
            {user?.role === 'admin' && (
              <button 
                onClick={() => onNavigate('admin')}
                className={`flex items-center space-x-2 text-sm font-bold tracking-tight transition-all bg-indigo-50 text-indigo-700 px-4 py-2 rounded-xl border border-indigo-100`}
              >
                <LayoutDashboard size={16} />
                <span>Admin Dashboard</span>
              </button>
            )}
          </div>

          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-3 px-4 py-2 rounded-2xl border border-slate-100 bg-slate-50/50">
              <div className="w-9 h-9 bg-white text-indigo-600 border border-indigo-100 rounded-xl flex items-center justify-center font-black text-sm uppercase shadow-sm">
                {user?.name.charAt(0)}
              </div>
              <div className="hidden lg:block text-left">
                <p className="text-xs font-black text-slate-900 leading-none">{user?.name}</p>
                <p className="text-[10px] text-indigo-500 uppercase font-bold tracking-wider mt-1">{user?.role}</p>
              </div>
            </div>
            <button 
              onClick={onLogout}
              className="p-3 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-2xl transition-all border border-transparent hover:border-rose-100"
              title="Logout"
            >
              <LogOut size={22} />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
