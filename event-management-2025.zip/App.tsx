
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { User, Event, Registration, UserRole } from './types';
import { INITIAL_EVENTS } from './constants';
import Navbar from './components/Navbar';
import EventCard from './components/EventCard';
import { 
  ArrowRight, Search, Filter, Mail, Lock, 
  CheckCircle2, CreditCard, Wallet, QrCode,
  Users, BarChart3, ChevronRight, Bell, Calendar,
  ShieldCheck, Info, Sparkles, MapPin, Plus, Trash2, X, Edit2, Download, FileText, Printer, Upload, AlertTriangle, Check, LogIn, UserPlus
} from 'lucide-react';
import { QRCodeCanvas } from 'qrcode.react';

// --- Helper Functions ---

const downloadReceiptAsFile = (reg: Registration, event: Event | undefined) => {
  const content = `
--------------------------------------------------
          EVENT MANAGEMENT PORTAL 2025
                OFFICIAL ENTRY PASS
--------------------------------------------------
Pass ID:        ${reg.id}
Generated:      ${reg.timestamp}

[STUDENT INFO]
Name:           ${reg.userName}
Email:          ${reg.userEmail}

[EVENT INFO]
Title:          ${reg.eventTitle}
Date:           ${event?.date || 'N/A'}
Time:           ${event?.time || 'N/A'}
Venue:          ${event?.venue || 'Bellary'}

[PAYMENT INFO]
Method:         ${reg.paymentMethod.toUpperCase()}
Status:         ${reg.status.toUpperCase()}
Amount:         ₹${event?.price || 0}

SECURITY NOTICE:
Please present the QR code from the app 
at the entry gate. This pass is non-transferable.
--------------------------------------------------
  `;
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `Ticket-${reg.eventTitle.replace(/\s+/g, '-')}-${reg.id.slice(-4)}.txt`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

// --- Main Application ---

export default function App() {
  const [view, setView] = useState<'landing' | 'login' | 'register' | 'admin' | 'dashboard'>('landing');
  const [currentSubView, setCurrentSubView] = useState<'events' | 'admin-panel' | 'my-bookings'>('events');
  const [user, setUser] = useState<User | null>(null);
  
  // Mock User Database for Registration -> Login flow
  const [registeredUsers, setRegisteredUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('nexus_registered_users');
    return saved ? JSON.parse(saved) : [];
  });

  const [events, setEvents] = useState<Event[]>(() => {
    const saved = localStorage.getItem('nexus_events');
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [bookingPayment, setBookingPayment] = useState<'cash' | 'online'>('online');
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [reminders, setReminders] = useState<{id: string, title: string, date: string}[]>([]);
  const [viewReceipt, setViewReceipt] = useState<Registration | null>(null);
  const [confirmCancelId, setConfirmCancelId] = useState<string | null>(null);
  const [authMessage, setAuthMessage] = useState<string | null>(null);

  // Admin Image Handling
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [imageConfirmed, setImageConfirmed] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        setImageConfirmed(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleConfirmImage = () => {
    if (uploadedImage) setImageConfirmed(true);
  };

  const filteredEvents = useMemo(() => {
    return events.filter(e => {
      const matchSearch = e.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          e.venue.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCategory = categoryFilter === 'All' || e.category === categoryFilter;
      return matchSearch && matchCategory;
    });
  }, [events, searchTerm, categoryFilter]);

  const categories = ['All', ...new Set(events.map(e => e.category))];

  useEffect(() => {
    const savedUser = localStorage.getItem('nexus_user');
    const savedRegs = localStorage.getItem('nexus_regs');
    if (savedUser) {
      const u = JSON.parse(savedUser);
      setUser(u);
      setView('dashboard');
      setCurrentSubView(u.role === 'admin' ? 'admin-panel' : 'events');
    }
    if (savedRegs) {
      setRegistrations(JSON.parse(savedRegs));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('nexus_events', JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem('nexus_registered_users', JSON.stringify(registeredUsers));
  }, [registeredUsers]);

  useEffect(() => {
    if (!user) return;
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];
    const userRegs = registrations.filter(r => r.userId === user.id);
    const tomorrowEvents = events.filter(e => e.date === tomorrowStr && userRegs.some(r => r.eventId === e.id));
    if (tomorrowEvents.length > 0) {
      setReminders(tomorrowEvents.map(e => ({ id: e.id, title: e.title, date: 'Tomorrow' })));
    }
  }, [user, registrations, events]);

  const handleRegister = (data: any) => {
    const existing = registeredUsers.find(u => u.email === data.email);
    if (existing) {
      setAuthMessage("Email already registered. Please login.");
      return;
    }
    const newUser: User = { 
      id: Math.random().toString(36).substr(2, 9), 
      email: data.email, 
      name: data.name, 
      role: data.role || 'user' 
    };
    setRegisteredUsers([...registeredUsers, newUser]);
    setAuthMessage("Registration successful! Please login to your account.");
    setView('login');
  };

  const handleLogin = (data: any) => {
    if (data.role === 'admin') {
      // Simple hardcoded admin check for demo, otherwise use registeredUsers
      const adminUser: User = { id: 'admin-1', email: data.email, name: 'Main Admin', role: 'admin' };
      setUser(adminUser);
      localStorage.setItem('nexus_user', JSON.stringify(adminUser));
      setView('dashboard');
      setCurrentSubView('admin-panel');
      return;
    }

    const found = registeredUsers.find(u => u.email === data.email);
    if (found) {
      setUser(found);
      localStorage.setItem('nexus_user', JSON.stringify(found));
      setView('dashboard');
      setCurrentSubView('events');
      setAuthMessage(null);
    } else {
      setAuthMessage("Invalid credentials or user not found. Please register first.");
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('nexus_user');
    setView('landing');
    setAuthMessage(null);
  };

  const handleBooking = () => {
    if (!selectedEvent || !user) return;
    const newReg: Registration = {
      id: `REG-${Math.random().toString(36).toUpperCase().substr(2, 8)}`,
      userId: user.id, eventId: selectedEvent.id, userName: user.name, userEmail: user.email, eventTitle: selectedEvent.title,
      status: bookingPayment === 'online' ? 'paid' : 'pending', paymentMethod: bookingPayment, qrCode: `BALLARI-2025-${selectedEvent.id}-${user.id}`,
      timestamp: new Date().toLocaleString()
    };
    const updatedRegs = [...registrations, newReg];
    setRegistrations(updatedRegs);
    localStorage.setItem('nexus_regs', JSON.stringify(updatedRegs));
    setEvents(events.map(e => e.id === selectedEvent.id ? { ...e, attendeesCount: e.attendeesCount + 1 } : e));
    setShowBookingModal(false);
    setViewReceipt(newReg);
  };

  const handleCancelBooking = (regId: string) => {
    const regToRemove = registrations.find(r => r.id === regId);
    if (!regToRemove) return;
    const updatedRegs = registrations.filter(r => r.id !== regId);
    setRegistrations(updatedRegs);
    localStorage.setItem('nexus_regs', JSON.stringify(updatedRegs));
    setEvents(events.map(e => e.id === regToRemove.eventId ? { ...e, attendeesCount: Math.max(0, e.attendeesCount - 1) } : e));
    setConfirmCancelId(null);
  };

  const handleSaveEvent = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const imageUrlField = formData.get('imageUrl') as string;
    let finalImage = editingEvent?.image || `https://images.unsplash.com/photo-${Math.floor(Math.random() * 1000000)}?auto=format&fit=crop&q=80&w=800`;
    
    if (uploadedImage) finalImage = uploadedImage;
    else if (imageUrlField) finalImage = imageUrlField;

    const eventData = {
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      date: formData.get('date') as string,
      time: formData.get('time') as string,
      venue: formData.get('venue') as string || 'Bellary',
      maxCapacity: parseInt(formData.get('maxCapacity') as string) || 100,
      category: formData.get('category') as string,
      price: parseInt(formData.get('price') as string) || 0,
      image: finalImage
    };

    if (editingEvent) {
      setEvents(events.map(ev => ev.id === editingEvent.id ? { ...ev, ...eventData } : ev));
    } else {
      const newEvent: Event = {
        id: `e-${Date.now()}`,
        ...eventData,
        attendeesCount: 0,
        schedule: [{ time: eventData.time, activity: 'Main Event Starts' }]
      };
      setEvents([...events, newEvent]);
    }
    
    setShowCreateModal(false);
    setEditingEvent(null);
    setUploadedImage(null);
    setImageConfirmed(false);
  };

  const handleDeleteEvent = (id: string) => {
    if (!window.confirm("Delete this event? All associated tickets will become invalid.")) return;
    setEvents(events.filter(e => e.id !== id));
    setRegistrations(registrations.filter(r => r.eventId !== id));
  };

  // --- Render Sections ---

  const LandingPageContent = () => (
    <div className="min-h-screen flex flex-col bg-white overflow-hidden">
      <div className="relative flex-1 flex flex-col items-center justify-center px-6 py-24 text-center">
        <div className="absolute top-20 -left-20 w-96 h-96 bg-indigo-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 -right-20 w-96 h-96 bg-violet-400/10 rounded-full blur-3xl animate-pulse delay-700"></div>

        <div className="relative z-10 max-w-5xl mx-auto">
          <div className="inline-flex items-center space-x-2 px-4 py-2 bg-indigo-50 border border-indigo-100 rounded-full text-indigo-700 text-xs font-black uppercase tracking-widest mb-10 shadow-sm">
            <Sparkles size={14} className="animate-pulse" />
            <span>Campus Hub 2025</span>
          </div>
          
          <h1 className="text-7xl md:text-9xl font-black mb-8 text-slate-900 tracking-tighter leading-tight">
            Event <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">Management</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-slate-500 mb-14 max-w-3xl mx-auto font-medium leading-relaxed">
            Register and manage your campus life in <span className="text-slate-900 font-bold">Bellary</span>. 
            Discover Kishkindha University festivals, workshops, and celebrations.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center w-full">
            <button 
              onClick={() => setView('register')}
              className="group w-full sm:w-auto flex items-center justify-center space-x-3 bg-slate-900 text-white px-10 py-5 rounded-[2rem] font-black text-xl hover:bg-indigo-600 transition-all shadow-2xl active:scale-95"
            >
              <UserPlus size={24} />
              <span>Get Started</span>
              <ArrowRight size={24} className="group-hover:translate-x-1 transition-transform" />
            </button>
            
            <button 
              onClick={() => setView('admin')}
              className="w-full sm:w-auto flex items-center justify-center space-x-3 bg-white text-slate-900 border-2 border-slate-100 px-10 py-5 rounded-[2rem] font-black text-xl hover:border-indigo-600 hover:text-indigo-600 transition-all active:scale-95 shadow-lg"
            >
              <ShieldCheck size={24} />
              <span>Admin Portal</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const AuthPage: React.FC<{ 
    mode: 'login' | 'register' | 'admin', 
    onSubmit: (data: any) => void,
    onBack: () => void,
    toggleMode: () => void 
  }> = ({ mode, onSubmit, onBack, toggleMode }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      onSubmit({ email, password, name, role: mode === 'admin' ? 'admin' : 'user' });
    };

    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="w-full max-w-lg bg-white rounded-[3rem] shadow-2xl p-12 border border-slate-100">
          <button onClick={onBack} className="mb-10 text-slate-400 hover:text-indigo-600 flex items-center text-sm font-black transition-colors uppercase tracking-widest">
            <ChevronRight size={18} className="rotate-180 mr-2" />
            Back
          </button>

          <div className="text-center mb-10">
            <h2 className="text-4xl font-black text-slate-900 mb-3 tracking-tight">
              {mode === 'login' ? 'Sign In' : mode === 'register' ? 'Register Now' : 'Admin Gateway'}
            </h2>
            <p className="text-slate-500 font-medium">
              {mode === 'register' ? 'Create your student account' : 'Welcome to the 2025 Portal'}
            </p>
          </div>

          {authMessage && (
            <div className="mb-6 p-4 bg-indigo-50 border border-indigo-100 rounded-2xl text-indigo-700 text-sm font-bold flex items-center">
              <Info size={18} className="mr-3 shrink-0" />
              {authMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">Full Name</label>
                <input required type="text" value={name} onChange={(e) => setName(e.target.value)} className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" placeholder="Student Name" />
              </div>
            )}
            <div>
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">Email Address</label>
              <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" placeholder="name@college.edu" />
            </div>
            <div>
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">Password</label>
              <input required type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" placeholder="••••••••" />
            </div>

            <button className="w-full py-5 bg-slate-900 text-white rounded-[2rem] font-black text-lg shadow-2xl hover:bg-indigo-600 transition-all flex items-center justify-center space-x-3">
              {mode === 'login' ? <LogIn size={20} /> : <UserPlus size={20} />}
              <span>{mode === 'login' ? 'Sign In' : mode === 'register' ? 'Register Account' : 'Admin Login'}</span>
            </button>
          </form>

          <div className="mt-10 pt-8 border-t border-slate-100 text-center">
            {mode !== 'admin' && (
              <button onClick={toggleMode} className="text-indigo-600 font-black text-sm tracking-tight transition-all hover:underline">
                {mode === 'login' ? "New student? Register first" : "Already have an account? Sign in here"}
              </button>
            )}
          </div>
        </div>
      </div>
    );
  };

  if (view === 'landing') return <LandingPageContent />;
  if (view === 'login') return <AuthPage mode="login" onSubmit={handleLogin} onBack={() => setView('landing')} toggleMode={() => setView('register')} />;
  if (view === 'register') return <AuthPage mode="register" onSubmit={handleRegister} onBack={() => setView('landing')} toggleMode={() => setView('login')} />;
  if (view === 'admin') return <AuthPage mode="admin" onSubmit={handleLogin} onBack={() => setView('landing')} toggleMode={() => {}} />;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar user={user} onLogout={handleLogout} onNavigate={(v) => setCurrentSubView(v === 'admin' ? 'admin-panel' : v)} currentView={currentSubView} />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full">
        {reminders.length > 0 && currentSubView === 'events' && (
          <div className="mb-10 bg-indigo-600 p-8 rounded-[2.5rem] shadow-2xl text-white flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <Bell size={32} className="animate-bounce" />
              <div>
                <h4 className="text-2xl font-black">Email Reminder Active</h4>
                <p className="text-white/80 font-medium">Ethnic Day tomorrow! Check your registered email for details.</p>
              </div>
            </div>
            <Mail size={48} className="opacity-20" />
          </div>
        )}

        {currentSubView === 'events' && (
          <div>
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-12 gap-8">
              <div>
                <h1 className="text-5xl font-black text-slate-900 tracking-tight">Kishkindha 2025</h1>
                <p className="text-slate-500 font-bold mt-2 flex items-center"><MapPin size={18} className="mr-2 text-indigo-500" /> Bellary Campus Events</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative">
                  <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
                  <input type="text" placeholder="Search events..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-12 pr-6 py-4 bg-white border border-slate-200 rounded-2xl w-full sm:w-72 font-bold shadow-sm outline-none focus:ring-4 focus:ring-indigo-100" />
                </div>
                <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} className="bg-white border border-slate-200 rounded-2xl px-6 py-4 font-black shadow-sm outline-none cursor-pointer">
                  {categories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
              {filteredEvents.map(event => (
                <EventCard key={event.id} event={event} onClick={(e) => { setSelectedEvent(e); setShowBookingModal(true); }} />
              ))}
            </div>
          </div>
        )}

        {currentSubView === 'my-bookings' && (
          <div>
            <h1 className="text-5xl font-black text-slate-900 mb-12">My Entry Passes</h1>
            <div className="grid grid-cols-1 gap-8">
              {registrations.filter(r => r.userId === user?.id).map(reg => {
                const event = events.find(e => e.id === reg.eventId);
                return (
                  <div key={reg.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-xl flex flex-col md:flex-row items-center gap-10 relative overflow-hidden group hover:border-indigo-200 transition-all">
                    <div className="bg-slate-50 p-6 rounded-[2rem] shadow-inner border border-slate-100 shrink-0"><QRCodeCanvas value={reg.qrCode} size={140} /></div>
                    <div className="flex-1">
                      <span className="px-4 py-1.5 rounded-full text-xs font-black bg-emerald-100 text-emerald-700 uppercase tracking-widest">{reg.status}</span>
                      <h3 className="text-3xl font-black text-slate-900 leading-tight mt-3 mb-1">{reg.eventTitle}</h3>
                      <p className="text-slate-500 font-bold flex items-center"><Calendar size={18} className="mr-2 text-indigo-400" /> {event?.date} • {event?.time}</p>
                      <p className="text-slate-400 font-medium text-sm mt-1">Venue: Kishkindha Campus, {event?.venue}</p>
                    </div>
                    <div className="flex flex-col gap-3 w-full md:w-auto">
                      <button onClick={() => setViewReceipt(reg)} className="px-10 py-5 bg-indigo-600 text-white rounded-[2rem] font-black hover:bg-indigo-700 transition-all shadow-xl flex items-center justify-center space-x-2">
                        <FileText size={18} />
                        <span>Receipt / Pass</span>
                      </button>
                      <button 
                        onClick={() => setConfirmCancelId(reg.id)}
                        className="px-10 py-5 bg-rose-50 text-rose-600 border border-rose-100 rounded-[2rem] font-black hover:bg-rose-600 hover:text-white transition-all flex items-center justify-center space-x-2"
                      >
                        <Trash2 size={18} />
                        <span>Cancel Booking</span>
                      </button>
                    </div>
                    <div className="absolute top-1/2 -left-4 w-8 h-8 bg-slate-50 rounded-full"></div>
                    <div className="absolute top-1/2 -right-4 w-8 h-8 bg-slate-50 rounded-full"></div>
                  </div>
                );
              })}
              {registrations.filter(r => r.userId === user?.id).length === 0 && (
                <div className="text-center py-32 bg-white rounded-[3rem] border-4 border-dashed border-slate-100">
                  <QrCode size={80} className="mx-auto text-slate-100 mb-8" />
                  <p className="text-slate-400 font-black text-3xl tracking-tight">You haven't booked any events yet.</p>
                  <button onClick={() => setCurrentSubView('events')} className="mt-8 px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black shadow-lg hover:bg-indigo-700 transition-all">Explore Events</button>
                </div>
              )}
            </div>
          </div>
        )}

        {currentSubView === 'admin-panel' && user?.role === 'admin' && (
          <div className="space-y-12">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-10">
              <h1 className="text-5xl font-black text-slate-900 tracking-tight">Admin Dashboard</h1>
              <button 
                onClick={() => { setEditingEvent(null); setUploadedImage(null); setImageConfirmed(false); setShowCreateModal(true); }} 
                className="bg-indigo-600 text-white px-10 py-5 rounded-[2.5rem] shadow-2xl flex items-center font-black space-x-3 hover:bg-indigo-700 transition-all active:scale-95"
              >
                <Plus size={24} />
                <span>Add Event</span>
              </button>
            </div>

            <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden mb-12">
              <div className="p-10 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                <h3 className="text-2xl font-black text-slate-900">Live Campus Events</h3>
                <BarChart3 size={24} className="text-slate-300" />
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-10 py-6 text-xs font-black text-slate-400 uppercase tracking-widest">Title & Category</th>
                      <th className="px-10 py-6 text-xs font-black text-slate-400 uppercase tracking-widest text-center">Event Date</th>
                      <th className="px-10 py-6 text-xs font-black text-slate-400 uppercase tracking-widest text-center">Registration Info</th>
                      <th className="px-10 py-6 text-xs font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {events.map(event => (
                      <tr key={event.id} className="hover:bg-indigo-50/20 transition-all group">
                        <td className="px-10 py-8">
                          <p className="font-black text-slate-900">{event.title}</p>
                          <p className="text-sm font-bold text-slate-400">{event.category}</p>
                        </td>
                        <td className="px-10 py-8 text-center font-bold text-slate-600">{event.date}</td>
                        <td className="px-10 py-8 text-center">
                          <div className="flex flex-col items-center">
                            <span className="font-black text-indigo-600">{event.attendeesCount} / {event.maxCapacity}</span>
                            <div className="w-24 h-1.5 bg-slate-100 rounded-full mt-2 overflow-hidden">
                              <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${(event.attendeesCount / event.maxCapacity) * 100}%` }}></div>
                            </div>
                          </div>
                        </td>
                        <td className="px-10 py-8 text-right">
                          <div className="flex justify-end gap-3">
                            <button 
                              onClick={() => { setEditingEvent(event); setUploadedImage(event.image); setImageConfirmed(true); setShowCreateModal(true); }}
                              className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all"
                            >
                              <Edit2 size={18} />
                            </button>
                            <button 
                              onClick={() => handleDeleteEvent(event.id)}
                              className="p-4 bg-rose-50 text-rose-600 rounded-2xl hover:bg-rose-600 hover:text-white transition-all"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            
            <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden">
               <div className="p-10 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                  <h3 className="text-2xl font-black text-slate-900">Student Bookings & Payments</h3>
                  <Users size={24} className="text-slate-300" />
               </div>
               <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-10 py-6 text-xs font-black text-slate-400 uppercase tracking-widest">Student Info</th>
                      <th className="px-10 py-6 text-xs font-black text-slate-400 uppercase tracking-widest">Target Event</th>
                      <th className="px-10 py-6 text-xs font-black text-slate-400 uppercase tracking-widest text-center">Payment Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {registrations.map(reg => (
                      <tr key={reg.id} className="hover:bg-indigo-50/20 transition-all">
                        <td className="px-10 py-8">
                          <p className="font-black text-slate-800">{reg.userName}</p>
                          <p className="text-sm font-bold text-slate-400">{reg.userEmail}</p>
                        </td>
                        <td className="px-10 py-8 font-black text-slate-900">{reg.eventTitle}</td>
                        <td className="px-10 py-8 text-center">
                          <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${reg.status === 'paid' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                            {reg.status} ({reg.paymentMethod})
                          </span>
                        </td>
                      </tr>
                    ))}
                    {registrations.length === 0 && (
                      <tr>
                        <td colSpan={3} className="px-10 py-16 text-center text-slate-400 font-bold">No student registrations recorded yet.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* --- Global Modals --- */}

      {/* Confirmation Dialog for Cancellation */}
      {confirmCancelId && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-xl" onClick={() => setConfirmCancelId(null)}></div>
          <div className="relative bg-white w-full max-w-md rounded-[3rem] p-12 shadow-2xl text-center">
            <div className="w-20 h-20 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-8">
              <AlertTriangle size={40} />
            </div>
            <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tight">Cancel Ticket?</h2>
            <p className="text-slate-500 font-medium mb-10 leading-relaxed">
              Are you sure? This will remove your seat from the event and your QR code will be invalidated permanently.
            </p>
            <div className="flex flex-col gap-4">
              <button 
                onClick={() => handleCancelBooking(confirmCancelId)}
                className="w-full py-5 bg-rose-600 text-white rounded-[2rem] font-black text-lg hover:bg-rose-700 transition-all shadow-xl shadow-rose-200"
              >
                Confirm Cancellation
              </button>
              <button 
                onClick={() => setConfirmCancelId(null)}
                className="w-full py-5 bg-slate-100 text-slate-900 rounded-[2rem] font-black text-lg hover:bg-slate-200 transition-all"
              >
                Go Back
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin: Create/Edit Event Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-xl" onClick={() => { setShowCreateModal(false); setEditingEvent(null); }}></div>
          <form onSubmit={handleSaveEvent} className="relative bg-white w-full max-w-xl rounded-[3rem] p-12 shadow-2xl overflow-y-auto max-h-[90vh]">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">{editingEvent ? 'Edit Event' : 'Launch New Event'}</h2>
              <button type="button" onClick={() => { setShowCreateModal(false); setEditingEvent(null); }} className="p-2 hover:bg-slate-100 rounded-full transition-colors"><X size={32} /></button>
            </div>
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Event Visuals</label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className={`w-full h-52 bg-slate-50 border-2 border-dashed rounded-[2rem] flex flex-col items-center justify-center cursor-pointer transition-all overflow-hidden relative group ${imageConfirmed ? 'border-emerald-500 bg-emerald-50/20' : 'border-slate-200 hover:border-indigo-600 hover:bg-white'}`}
                >
                  {uploadedImage ? (
                    <>
                      <img src={uploadedImage} className="w-full h-full object-cover" />
                      <div className={`absolute inset-0 flex flex-col items-center justify-center text-white transition-all ${imageConfirmed ? 'bg-emerald-600/60 opacity-100' : 'bg-black/40 opacity-0 group-hover:opacity-100'}`}>
                        {imageConfirmed ? (
                          <div className="flex flex-col items-center">
                            <div className="bg-white text-emerald-600 p-3 rounded-full mb-3"><Check size={28} /></div>
                            <span className="font-black text-sm tracking-wider">POSTER CONFIRMED</span>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center">
                            <Upload size={32} className="mb-3 animate-pulse" />
                            <span className="font-black text-sm uppercase tracking-widest">Change Image</span>
                          </div>
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="text-center p-8">
                      <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-sm text-slate-300">
                        <Upload size={32} />
                      </div>
                      <p className="text-sm font-black text-slate-900 mb-1">Upload Event Image</p>
                      <p className="text-xs font-bold text-slate-400">Click to select from your device</p>
                    </div>
                  )}
                </div>
                {uploadedImage && !imageConfirmed && (
                   <button 
                    type="button"
                    onClick={handleConfirmImage}
                    className="w-full py-4 mt-3 bg-emerald-500 text-white rounded-2xl font-black text-sm flex items-center justify-center space-x-2 shadow-xl shadow-emerald-100 hover:bg-emerald-600 transition-all scale-100 active:scale-95"
                   >
                     <Check size={20} />
                     <span>Lock Image as Poster</span>
                   </button>
                )}
                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
                
                <div className="relative mt-4">
                  <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                    <MapPin size={18} className="text-slate-300" />
                  </div>
                  <input name="imageUrl" defaultValue={editingEvent?.image} placeholder="Or paste full image path/URL..." className="w-full pl-12 pr-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold text-sm outline-none focus:ring-4 focus:ring-indigo-100 transition-all" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Title</label>
                <input required name="title" defaultValue={editingEvent?.title} placeholder="e.g. Ethnic Day 2025" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Event Date</label>
                  <input required name="date" type="date" defaultValue={editingEvent?.date} className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Start Time</label>
                  <input required name="time" type="time" defaultValue={editingEvent?.time} className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Entry Price (₹)</label>
                  <input required name="price" type="number" defaultValue={editingEvent?.price} placeholder="0 for Free" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Capacity</label>
                  <input required name="maxCapacity" type="number" defaultValue={editingEvent?.maxCapacity} placeholder="e.g. 500" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Description</label>
                <textarea required name="description" defaultValue={editingEvent?.description} placeholder="Marketing description..." rows={3} className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold" />
              </div>
              
              <button 
                type="submit"
                className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black text-xl shadow-2xl hover:bg-indigo-600 transition-all flex items-center justify-center space-x-3 active:scale-[0.98]"
              >
                <span>{editingEvent ? 'Update Event' : 'Create Event'}</span>
                <ArrowRight size={24} />
              </button>
            </div>
          </form>
        </div>
      )}

      {/* User: Booking Payment Modal */}
      {showBookingModal && selectedEvent && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-xl" onClick={() => setShowBookingModal(false)}></div>
          <div className="relative bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-8 duration-500">
            <div className="relative h-72">
              <img src={selectedEvent.image} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 flex items-end p-12">
                <h2 className="text-5xl font-black text-white tracking-tighter line-clamp-2">{selectedEvent.title}</h2>
              </div>
              <button onClick={() => setShowBookingModal(false)} className="absolute top-8 right-8 text-white bg-black/20 p-2 rounded-full hover:rotate-90 transition-transform backdrop-blur-md"><X size={32} /></button>
            </div>
            <div className="p-12">
               <h4 className="text-xs font-black text-slate-300 uppercase tracking-widest mb-6">Payment Preference</h4>
               <div className="flex gap-6 mb-12">
                  <button onClick={() => setBookingPayment('online')} className={`flex-1 p-8 rounded-[2.5rem] border-2 transition-all flex flex-col items-center ${bookingPayment === 'online' ? 'border-indigo-600 bg-indigo-50 shadow-2xl shadow-indigo-100' : 'border-slate-100 hover:border-slate-300'}`}>
                    <CreditCard size={32} className={bookingPayment === 'online' ? 'text-indigo-600' : 'text-slate-300'} />
                    <span className={`font-black text-lg mt-3 ${bookingPayment === 'online' ? 'text-indigo-900' : 'text-slate-400'}`}>Pay Online</span>
                    <span className="text-[10px] uppercase font-black tracking-widest opacity-40 mt-1">Instant Receipt</span>
                  </button>
                  <button onClick={() => setBookingPayment('cash')} className={`flex-1 p-8 rounded-[2.5rem] border-2 transition-all flex flex-col items-center ${bookingPayment === 'cash' ? 'border-indigo-600 bg-indigo-50 shadow-2xl shadow-indigo-100' : 'border-slate-100 hover:border-slate-300'}`}>
                    <Wallet size={32} className={bookingPayment === 'cash' ? 'text-indigo-600' : 'text-slate-300'} />
                    <span className={`font-black text-lg mt-3 ${bookingPayment === 'cash' ? 'text-indigo-900' : 'text-slate-400'}`}>Pay Cash</span>
                    <span className="text-[10px] uppercase font-black tracking-widest opacity-40 mt-1">Pay at Venue</span>
                  </button>
               </div>
               <div className="flex items-center justify-between pt-12 border-t border-slate-100">
                <div>
                  <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">Total Due</p>
                  <p className="text-5xl font-black text-slate-900 mt-1 tracking-tighter">{selectedEvent.price > 0 ? `₹${selectedEvent.price}` : 'FREE'}</p>
                </div>
                <button onClick={handleBooking} className="px-16 py-7 bg-slate-900 text-white rounded-[2.5rem] font-black text-2xl hover:bg-indigo-600 transition-all flex items-center space-x-5 shadow-2xl active:scale-95">
                  <span>Confirm Ticket</span>
                  <ArrowRight size={28} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Entry Pass / Receipt Modal */}
      {viewReceipt && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-indigo-950/50 backdrop-blur-xl" onClick={() => setViewReceipt(null)}></div>
          <div className="relative bg-white w-full max-w-lg rounded-[4rem] shadow-2xl overflow-hidden animate-in zoom-in duration-300 border border-white/20">
            <div className="bg-slate-900 p-12 text-center text-white relative">
               <div className="w-24 h-24 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-emerald-500/40">
                  <CheckCircle2 size={48} className="text-white" />
               </div>
               <h2 className="text-4xl font-black mb-2 tracking-tight">Access Granted</h2>
               <p className="text-white/50 font-black tracking-widest uppercase text-xs">Official Pass ID: {viewReceipt.id}</p>
               <button onClick={() => setViewReceipt(null)} className="absolute top-8 right-8 text-white/40 hover:text-white transition-colors"><X size={28} /></button>
            </div>
            
            <div className="p-12 space-y-10">
               <div className="grid grid-cols-2 gap-10 border-b border-slate-100 pb-10">
                  <div>
                    <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest block mb-2">Event Title</label>
                    <p className="font-black text-slate-900 text-lg leading-tight line-clamp-2">{viewReceipt.eventTitle}</p>
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest block mb-2">Issue Date</label>
                    <p className="font-black text-slate-900 text-lg">{viewReceipt.timestamp.split(',')[0]}</p>
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest block mb-2">Student</label>
                    <p className="font-black text-slate-900 text-lg">{viewReceipt.userName}</p>
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest block mb-2">Status</label>
                    <p className="font-black text-indigo-600 uppercase tracking-tighter text-sm">{viewReceipt.status} via {viewReceipt.paymentMethod}</p>
                  </div>
               </div>

               <div className="bg-slate-50 p-10 rounded-[3rem] border-4 border-dashed border-slate-200 flex flex-col items-center">
                  <QRCodeCanvas value={viewReceipt.qrCode} size={180} />
                  <p className="text-[11px] font-mono font-bold text-slate-400 mt-6 tracking-[0.3em] uppercase">{viewReceipt.qrCode}</p>
               </div>

               <div className="flex flex-col gap-5 pt-4">
                  <button 
                    onClick={() => downloadReceiptAsFile(viewReceipt, events.find(e => e.id === viewReceipt.eventId))}
                    className="w-full py-6 bg-indigo-600 text-white rounded-[2rem] font-black shadow-2xl hover:bg-indigo-700 transition-all flex items-center justify-center space-x-4 active:scale-[0.98]"
                  >
                    <Download size={24} />
                    <span>Download Official Pass</span>
                  </button>
                  <button 
                    onClick={() => window.print()}
                    className="w-full py-5 bg-white border-2 border-slate-100 text-slate-400 rounded-[2rem] font-black flex items-center justify-center space-x-4 hover:border-slate-300 hover:text-slate-600 transition-all"
                  >
                    <Printer size={20} />
                    <span>Print Transaction</span>
                  </button>
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
