
import { Event } from './types';

const DEFAULT_VENUE = 'Bellary';

export const INITIAL_EVENTS: Event[] = [
  {
    id: 'e1',
    title: 'Ethnic Day 2025',
    description: 'A grand celebration of cultural diversity and heritage at Kishkindha University. Show off your traditional roots!',
    date: '2025-05-15',
    time: '10:00 AM',
    venue: DEFAULT_VENUE,
    attendeesCount: 450,
    maxCapacity: 600,
    category: 'Cultural',
    price: 0,
    image: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&q=80&w=800',
    schedule: [
      { time: '10:00 AM', activity: 'Traditional Parade' },
      { time: '12:00 PM', activity: 'Folk Performance' },
      { time: '03:00 PM', activity: 'Award Ceremony' }
    ]
  },
  {
    id: 'e2',
    title: 'Kishkindha University Navotas',
    description: 'The signature annual youth festival bringing together students from across the region for music and sports.',
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
    time: '09:00 AM',
    venue: DEFAULT_VENUE,
    attendeesCount: 1200,
    maxCapacity: 2000,
    category: 'Festival',
    price: 150,
    image: 'https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?auto=format&fit=crop&q=80&w=800',
    schedule: [
      { time: '09:00 AM', activity: 'Inaugural Session' },
      { time: '02:00 PM', activity: 'Inter-College Dance' },
      { time: '08:00 PM', activity: 'Celebrity Night' }
    ]
  },
  {
    id: 'e3',
    title: 'New Year Celebration 2025',
    description: 'Welcome the new year with spectacular fireworks and a night of dance at the Kishkindha campus.',
    date: '2025-12-31',
    time: '07:00 PM',
    venue: DEFAULT_VENUE,
    attendeesCount: 3000,
    maxCapacity: 5000,
    category: 'Celebration',
    price: 300,
    image: 'https://images.unsplash.com/photo-1467810563316-b5476525c0f9?auto=format&fit=crop&q=80&w=800',
    schedule: [
      { time: '07:00 PM', activity: 'Opening DJ Set' },
      { time: '11:59 PM', activity: 'Grand Countdown' }
    ]
  }
];
